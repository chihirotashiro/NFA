#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define ROW 50
#define COL  20
#define LSIZ 1000 
char ArrayOfString[ROW][COL];

struct NFA {
   char  sym[LSIZ];
   char  states[LSIZ];
   char  start[LSIZ];
   char  final[LSIZ];
   char  trans[LSIZ];
   char string[LSIZ];
};
struct StackNode// Structure for stack nodes
{
	char *state;
  char *teststring;
	struct StackNode* next;  // Pointer to the next node
};
struct StackNode *top = NULL;

struct trans
{
char trans_path[ROW][COL];
char trans_des[ROW][COL];
char trans_start[ROW][COL];
};

struct two_d
{
char sym_2[ROW][COL];
char states_2[ROW][COL];
char start_2[ROW][COL];
char final_2[ROW][COL];
char trans_2[ROW][COL];
char strings_2[ROW][COL];
};

void push(char state[], char NFAstring[])
{
	struct StackNode* newNode;
	newNode = (struct StackNode*)malloc(sizeof(struct StackNode));
	newNode->state = state;
  newNode->teststring = NFAstring;

	if (top == NULL)
	{
		newNode->next = NULL;
		top = newNode;
	}
	else
	{
		newNode->next = top;
		top = newNode;
	}
}



struct StackNode pop(void)
{ struct StackNode pop;
	struct StackNode* ptr;
	ptr = top; //ptr will be use to delete a node
	if (top == NULL)
	{
		printf("\n STACK UNDERFLOW\n");//Stack is empty
	}
	else
	{		
 pop.state=top->state;
 pop.teststring=top->teststring;
  /* printf("\nThe value being deleted is: %s", top->state);
  printf("\nThe value being deleted is: %s", top->teststring); */

		top = top->next;
		free(ptr);
	}
  return pop;
} 


size_t vSeparateSringByComma (char* string)
{
    const char *delims = ",\n";
    char *s = string;
    size_t n = 0, len;

    for (s = strtok (s, delims); s && n < ROW; s = strtok (NULL, delims))
        if ((len = strlen (s)) < COL)
            strcpy (ArrayOfString[n++], s);
      else
            fprintf (stderr, "error: '%s' exceeds COL - 1 chars.\n", s);

    return n;
}

char* remove_par(char par[]){
  int i=0,j=0;
  char* no_par=malloc(LSIZ);;
   while(par[i] != '\0')
    {
    if(par[i] != '(' &&  par[i] != ')'&&par[i] != ' ')//Excluding brackets.
        {
            no_par[j++] = par[i];
        }
        i++;
    }
    no_par[j] = '\0';
  return no_par;
}
void algo(struct StackNode conf,struct two_d two_d, int p, int s, struct trans transition){
  
  int i;
  for (size_t k=0;k<p;k++){
push(two_d.start_2[0],two_d.strings_2[k]); 
printf("\npush string_2[%zu]--%s",k,two_d.strings_2[k]);
int accept=0;
 while(top!=NULL && accept==0){
 conf=pop();
 // printf("\nconf--%s,%s--\n",conf.teststring,conf.state);
int result = memcmp(conf.state, two_d.final_2[0],2);

  if((conf.teststring != NULL) && (conf.teststring[0] == '\0') && result==0){
    printf("\nAccepted\n");
    accept=1;
  }
  else if((conf.teststring != NULL) && (conf.teststring[0] == '\0') ){
    continue;
  }
  else {
   int i=0, j=0;
  char push_string[ROW][COL];
    
    push_string[0][0]=*(conf.teststring);
    //printf("push_string %s",push_string[0]);
    while (*(conf.teststring+i) != '\0')
    {
        if (i != 0)
        {
            *(conf.teststring+j) = *(conf.teststring+i);
            j++;
            i++;
        }
        else i++;
    }
    *(conf.teststring+j) = '\0';
   printf("conf.test---%s\n",conf.teststring);
    char next_state[ROW][COL];
    //printf("%s,%s,%s,%s",push_string[0],trans_path[1],conf.state,trans_des[1]);
for(i=0;i<s/3;i++){
  
  if(memcmp(push_string[0],transition.trans_path[i],2)==0&&memcmp(conf.state,transition.trans_start[i],2)==0){
    memcpy(next_state[i],transition.trans_des[i],2);
    printf("nextstate %s\n",next_state[i]);
    push(next_state[i],conf.teststring);}
  } 
    
  }
}
   
  if(accept==0){
    printf("\nRejected.");
  } 
  i=0;

  }
  }
void algo2(struct StackNode conf,struct two_d two_d, int s, struct trans transition){
  int k=0,i,count;
  do{
      printf("input string:");
    scanf("%s",two_d.strings_2[k]);
     int count=getchar();
      printf("%s",two_d.strings_2[k]);
    
   
     
    push(two_d.start_2[0],two_d.strings_2[k]); 
printf("\npush string_2[%d]--%s",k,two_d.strings_2[k]);
int accept=0;
 while(top!=NULL && accept==0){
 conf=pop();
 printf("\nconf--%s,%s--\n",conf.teststring,conf.state);
int result = memcmp(conf.state, two_d.final_2[0],2);

  if((conf.teststring != NULL) && (conf.teststring[0] == '\0') && result==0){
    printf("\nAccepted\n");
    accept=1;
  }
  else if((conf.teststring != NULL) && (conf.teststring[0] == '\0') ){
    continue;
  }
  else {
   int i=0, j=0;
  char push_string[ROW][COL];
    
    push_string[0][0]=*(conf.teststring);
    printf("push_string %s",push_string[0]);
    while (*(conf.teststring+i) != '\0')
    {
        if (i != 0)
        {
            *(conf.teststring+j) = *(conf.teststring+i);
            j++;
            i++;
        }
        else i++;
    }
    *(conf.teststring+j) = '\0';
    printf("conf.test---%s\n",conf.teststring);
    char next_state[ROW][COL];
    //printf("%s,%s,%s,%s",push_string[0],trans_path[1],conf.state,trans_des[1]);
for(i=0;i<s/3;i++){
  
  if(memcmp(push_string[0],transition.trans_path[i],2)==0&&memcmp(conf.state,transition.trans_start[i],2)==0){
    memcpy(next_state[i],transition.trans_des[i],2);
    printf("nextstate %s\n",next_state[i]);
    push(next_state[i],conf.teststring);}
  } 
    
  }
}
   
  if(accept==0){
    printf("\nRejected.");
  } 
  i=0;
 ++k; }while(count!=10&& count!=32);
  
 
  printf("Bye bye.\n");
    //exit(0);
    
  }
  

int main(){
  
FILE *fptr;
char string[100];
char fname[20];
int i=0;
int j=0 ;
char empty[]=" ()";
char line[20],line2[20],line3[20];
int idxToDel;
char ArrayOfString2[ROW][COL];
char *sym, *states,*start,*final,*trans,*strings;  
struct NFA nfa;
struct StackNode conf;
struct trans transition;
struct two_d two_d;
  
printf("Please input the file name: ");
scanf("%s",fname);
fptr=fopen(fname,"r");
fgets(line, LSIZ, fptr); 
fgets(line2, LSIZ, fptr); 
fgets(nfa.sym, LSIZ, fptr); 
fgets(nfa.states, LSIZ, fptr); 
printf("states %s",nfa.states);
fgets(nfa.start, LSIZ, fptr);
printf("start %s",nfa.start);
fgets(nfa.final, LSIZ, fptr); 
printf("final %s",nfa.final);
fgets(nfa.trans, LSIZ, fptr);
printf("trans %s",nfa.trans);
fgets(line3, LSIZ, fptr);
printf("line3 %s",line3);
fgets(nfa.string, LSIZ,fptr);
nfa.string[strcspn(nfa.string, "\n")] = 0;
printf("%s",nfa.string);
  
  sym=remove_par(nfa.sym);
  size_t n = vSeparateSringByComma (sym);
  memcpy(&two_d.sym_2,&ArrayOfString,sizeof(two_d.sym_2));
  
  states=remove_par(nfa.states);
  size_t m = vSeparateSringByComma (states);
  memcpy(&two_d.states_2,&ArrayOfString,sizeof(two_d.states_2));

  start=remove_par(nfa.start);
   size_t l = vSeparateSringByComma (start);
   memcpy(&two_d.start_2,&ArrayOfString,sizeof(two_d.start_2));
 
  final=remove_par(nfa.final);
  size_t o = vSeparateSringByComma (final);
  memcpy(&two_d.final_2,&ArrayOfString,sizeof(two_d.final_2));
 
  trans=remove_par(nfa.trans);
  size_t s= vSeparateSringByComma (trans);
   memcpy(&two_d.trans_2,&ArrayOfString,sizeof(two_d.trans_2));
   
  

  
  j=0;
  for(i=0;i<s;i+=3){
    
    memcpy(transition.trans_start[j],two_d.trans_2[i],2);
    //printf("start[%d]--%s\n",j,trans_start[j]);
    memcpy(transition.trans_path[j],two_d.trans_2[i+1],2);
  //printf("path[%d]%s\n",j,trans_path[j]);
    memcpy(transition.trans_des[j],two_d.trans_2[i+2],2);
    //printf("des[%d]%s\n",j,trans_des[j]);
    j++;
  }
  /* for(j=0;j<4;j++){
   printf("\n\nstart[%d]--%s\n",j,trans_start[j]);
    printf("path[%d]%s\n",j,trans_path[j]);
    printf("des[%d]%s\n",j,trans_des[j]);
  }
   */
size_t p;
int k=0;
if (strcmp(nfa.string,empty)!=0){
strings=remove_par(nfa.string);
p= vSeparateSringByComma (strings);
  printf("%zu",p);
  //printf("\n\nLength of strings--%zu",strlen(&strings[0]));
  memcpy(&two_d.strings_2,&ArrayOfString,sizeof(two_d.strings_2));
   for (size_t i = 0; i < p; i++){
         printf("\n\nstring[%zu] %s,\n",i,ArrayOfString[i]);
         printf("\n\nstring_2[%zu]-- %s,\n",i,two_d.strings_2[i]);
   //memcpy(strings_2[i],ArrayOfString[i],sizeof(strings_2));} 
     }
  algo(conf,two_d, p, s,transition);
  }

  else{
    do{
    algo2(conf,two_d, s,transition);
     
    }while(two_d.strings_2[k][0]!='\0');
  }
  return 0;
  }
  