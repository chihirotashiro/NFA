#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define ROW 50
#define COL  20
#define LSIZ 100 
char ArrayOfString[ROW][COL];

struct NFA {
   char  sym[LSIZ];
   char  states[LSIZ];
   char  start[LSIZ];
   char  final[LSIZ];
   char  trans[LSIZ];
   char string[LSIZ];
};
struct StackNode// Structure for stack nodes
{
	char *state;
  char *teststring;
	struct StackNode* next;  // Pointer to the next node
};
struct StackNode *top = NULL;

void push(char state[], char NFAstring[])
{
	struct StackNode* newNode;
	newNode = (struct StackNode*)malloc(sizeof(struct StackNode));
	newNode->state = state;
  newNode->teststring = NFAstring;

	if (top == NULL)
	{
		newNode->next = NULL;
		top = newNode;
	}
	else
	{
		newNode->next = top;
		top = newNode;
	}
}

void display()
{
	printf("\n\nDisplaying the Stack: ");
	struct StackNode* ptr;
	ptr = top;
	if (top == NULL)
	{
		printf("\n STACK IS EMPTY");
	}
	else
	{
		while (ptr != NULL)
		{
			printf("\n |%s|", ptr->state);
      printf("\n |%s|", ptr->teststring);

			ptr = ptr->next;
		}
	}
}

struct StackNode pop(void)
{ struct StackNode pop;
	struct StackNode* ptr;
	ptr = top; //ptr will be use to delete a node
	if (top == NULL)
	{
		printf("\n STACK UNDERFLOW\n");//Stack is empty
	}
	else
	{		
 pop.state=top->state;
 pop.teststring=top->teststring;
  /* printf("\nThe value being deleted is: %s", top->state);
  printf("\nThe value being deleted is: %s", top->teststring); */

		top = top->next;
		free(ptr);
	}
  return pop;
} 


size_t vSeparateSringByComma (char* string)
{
    const char *delims = ",\n";
    char *s = string;
    size_t n = 0, len;

    for (s = strtok (s, delims); s && n < ROW; s = strtok (NULL, delims))
        if ((len = strlen (s)) < COL)
            strcpy (ArrayOfString[n++], s);
      else
            fprintf (stderr, "error: '%s' exceeds COL - 1 chars.\n", s);

    return n;
}

char* remove_par(char par[]){
  int i=0,j=0;
  char* no_par=malloc(LSIZ);;
   while(par[i] != '\0')
    {
    if(par[i] != '(' &&  par[i] != ')'&&par[i] != ' ')//Excluding brackets.
        {
            no_par[j++] = par[i];
        }
        i++;
    }
    no_par[j] = '\0';
  return no_par;
}



int main(void) {
  
FILE *fptr;
char string[100];
char fname[20];
  int i=0;
  
  int j=0 ;
  char line[20],line2[20],line3[20];
  int idxToDel;
  char ArrayOfString2[ROW][COL];
  char empty[]=" ()";
   
  struct NFA nfa;
  
    printf("Please input the file name: ");
   scanf("%s",fname);
  fptr=fopen(fname,"r");
   fgets(line, LSIZ, fptr); 
  fgets(line2, LSIZ, fptr); 
  fgets(nfa.sym, LSIZ, fptr); 
  fgets(nfa.states, LSIZ, fptr); 
  fgets(nfa.start, LSIZ, fptr);
  fgets(nfa.final, LSIZ, fptr); 
  fgets(nfa.trans, LSIZ, fptr);
  fgets(line3, LSIZ, fptr);
  fgets(nfa.string, LSIZ,fptr);
  nfa.string[strcspn(nfa.string, "\n")] = 0;
  
if(strcmp(nfa.string,empty)==0) {
  printf("please input a string:");
  scanf("%s",nfa.string);
}   
  char *sym, *states,*start,*final,*strings;
  sym=remove_par(nfa.sym);
  states=remove_par(nfa.states);
  start=remove_par(nfa.start);
  final=remove_par(nfa.final);
  strings=remove_par(nfa.string);
  //printf("%s\n%s\n%s\n%s\n%s",sym,states,start,final,strings);

char sym_2[ROW][COL];
char states_2[ROW][COL];
char start_2[ROW][COL];
char final_2[ROW][COL];
char strings_2[ROW][COL];
size_t n = vSeparateSringByComma (sym);
 for (size_t i = 0; i < n; i++){
   strcpy(sym_2[i],ArrayOfString[i]);
   }
size_t m = vSeparateSringByComma (states);
for (size_t i = 0; i < m; i++)
        strcpy(states_2[i],ArrayOfString[i]);
size_t l = vSeparateSringByComma (start);
 for (size_t i = 0; i < l; i++){
   strcpy(start_2[i],ArrayOfString[i]);
   }
size_t o = vSeparateSringByComma (final);
for (size_t i = 0; i < o; i++)
       strcpy(final_2[i],ArrayOfString[i]);;
  size_t p= vSeparateSringByComma (strings);
 for (size_t i = 0; i < p; i++){
   strcpy(strings_2[i],ArrayOfString[i]);
   }

printf("\nstart--%s,%s",start_2[0],strings_2[0]);
for (size_t i=0;i<p;i++){
push(start_2[0],strings_2[i]); 
struct StackNode conf;
 while(top!=NULL){
 conf=pop();
  printf("\nconf--%s,%s--\n",conf.teststring,conf.state);
int result = strcmp(conf.state, final_2[0]);

  if(conf.teststring==NULL && result==0){
    printf("Accepted");
  }
  else if(conf.teststring==NULL){
    continue;
  }
  else{
   idxToDel=0;
  memmove(&ArrayOfString[19][idxToDel], &ArrayOfString[19][idxToDel + 1], strlen(ArrayOfString[19]) - idxToDel); 
    printf("%s",ArrayOfString[19]);
  //for(i=7;i<19;i++){ 
  //printf("skip=%s, array[%d]\n",ArrayOfString[i],i);
  /* strcpy(ArrayOfString2[i],ArrayOfString[i]);
    printf("array2 %s\n",ArrayOfString2[i]); */
  /* if(ArrayOfString[i]==top->state){
    }
  for(i=8;i<18;i+=3){
    printf("path is %c\n",ArrayOfString[i][0]);
    if(ArrayOfString[i][0]==ArrayOfString[19][0]){
     
    }
  } */
    
/* }
  printf("top is %s",top->state); 
pop();
  }
  
}

printf("top is %s",top->state); 
pop();
display(); */
//printf("%s",top->state);
/* for(i=7;i<17;i+=3){
  printf("skip=%s, array[%d]\n",ArrayOfString[i],i);
  if(ArrayOfString[i]==top->state)
}
 */
  } 
   
}
  }
  return 0;
  }