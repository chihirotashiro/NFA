Project Members: Vu Le, Chihiro Tashiro, Cory Yoon
Our project uses C language to implement the algorithm.
We use Replit to compile and run the program.
Replit is a free online compiler that is very easy to use.
To compile and run our program, simply go on Replit and create an account,
then hit the button "Create" and load our source code as well as
"proj-1-machine.txt", "proj-1-machine-1.txt", "NFAtest1.txt", and "NFAtest2.txt".
The next step is to change the source code to "main.c" and run the program.
To run the code using command line:
Install MinGW.
Add the compiler path to your system environment variables.
Open an elevated command prompt window.
Enter the directory of the C code.
Type gcc main.c -o filename.exe and press Enter to compile.
Run the program by typing its name and pressing Enter.